Faryad 실습 보충: 알고리즘 노트북과 QAOA 실행 예산
2026-11-10 · 한국어 공개판 · PDF 8쪽
Agentic Tech Review Letters (ATRL)

index.html 또는 supplement.pdf를 열어 읽습니다.
기존 QML 18강: https://infant83.io/AI_Tech_Review/lectures/quantum-machine-learning/
이 보충은 별도의 독립 편집 자료이며 기존 147쪽 PDF를 교체하지 않습니다.

내용
- notebooks/: 원저자의 알고리즘 노트북 14개와 저장 출력, 변경 없음.
- notebook-catalog.csv: 기존 강의 연결 제안과 원출처·해시.
- data/: 공개 QAOA 장부 JSON 6개, 변경 없음.
- labs/: 보충 제작자의 오프라인 검산 코드 두 개와 기존 실행 결과.
- licenses/: 원저자 코드의 MIT 고지, 공개 데이터의 CC-BY-4.0 고지.
- sources.json: 확인한 원출처·판본·검토 범위.
- SHA256SUMS.txt: 이 파일을 제외한 공개 묶음의 SHA-256.

검산 실행 (이 폴더에서)
python3 labs/audit_qaoa.py --data-dir data --output qaoa-audit-rerun.json
python3 labs/audit_notebooks.py --source-dir . --output notebook-audit-rerun.json
첫 명령은 Python 표준 라이브러리만, 둘째는 NumPy를 사용합니다.
두 코드는 원저자 노트북을 실행하거나 장치에 작업을 제출하지 않습니다.
작은 모형의 이번 공개 검토 재실행에는 NumPy 2.0.2를 사용했습니다.

원저자 노트북을 별도로 실행할 때는 별도 환경과 실제 버전 기록이 필요합니다.
requirements-upstream.txt는 잠금 파일이 아닙니다.
QAOA 장치 노트북 6개는 아래 원출처에서 별도로 제공합니다. NB16a는
DRY_RUN=False가 기본이므로 로컬 모의실험을 원하면 실행 전 True로 바꿉니다.
이 묶음은 원저자 노트북 전체나 실제 QPU 실험의 재현 성공을 보증하지 않습니다.

공개 장부: 193작업, QPU 시간 추정 합계 약 33.6143분,
측정 제출-결과 wall time 합계 약 142.9255분.
논문의 metrics-key fallback 설명에 따라 QPU 시간 필드는 계측값으로 쓰지 않습니다.
95% 문턱은 각 방법 자신의 최종 무잡음 근사비 누적최댓값을 기준으로 합니다.

원출처·권리
Muhammad Faryad, Quantum Algorithms from First Principles companion notebooks:
https://github.com/muf148/quantum-algorithms-first-principles/tree/22954602b59d586c0727cf6110292b7000659db2
노트북·코드의 MIT 고지를 보존합니다. 책 본문은 재배포하지 않습니다.
Muhammad Faryad, qaoa-job-budget:
https://github.com/muf148/qaoa-job-budget/tree/438b205b9bfd072038f4d342cf6adb89b1bdbb02
여섯 데이터 파일은 CC-BY-4.0, 저작자 Muhammad Faryad이며 변경하지 않았습니다.
논문: https://arxiv.org/html/2609.13669v1
편집한 보충 설명에 원자료의 라이선스를 일괄 적용하지 않습니다.

책임 편집자 김현중 · AI 보조 OpenAI Codex.
faryad_science_package: 원출처·라이선스·검산 대조, 웹 안내와 자료 묶음 편집.
faryad_pdf_review: PDF 정제·내용 보존·링크·전체 8쪽 조판 검수.
root: 기존 강의 연결·등록·발행 통합. 사람의 원고 감수는 수행하지 않았습니다.
