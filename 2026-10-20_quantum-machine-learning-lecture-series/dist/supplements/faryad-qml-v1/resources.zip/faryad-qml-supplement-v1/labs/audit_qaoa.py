#!/usr/bin/env python3
"""Audit released QAOA JSON ledgers and table metrics using the standard library.

Reads local files only. Does not import notebooks, contact IBM, submit jobs, or
re-run a hardware experiment. The input JSON's noiseless ratios are audited as
released diagnostic values; this script does not independently simulate them.

Usage:
  python3 audit_qaoa.py --data-dir /path/to/qaoa-job-budget/data --output results.json
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import mean


COMMIT = "438b205b9bfd072038f4d342cf6adb89b1bdbb02"
UPSTREAM = "https://github.com/muf148/qaoa-job-budget/tree/" + COMMIT
NAMES = ["6assets", "8assets", "10assets", "12assets", "depth_scan", "replicates_8assets"]


def running_max(values):
    result = []
    best = -math.inf
    for value in values:
        best = max(best, float(value))
        result.append(best)
    if not result:
        raise ValueError("Empty ideal_ratio trace")
    return result


def first_job(values, threshold):
    return next((i + 1 for i, value in enumerate(values) if value >= threshold), None)


def quality_metrics(run):
    """Paper Tables 4/7: running maxima of released exact noiseless ratios."""
    batched = running_max(run["bps"]["trace"]["ideal_ratio"])
    serial = running_max(run["serial"]["trace"]["ideal_ratio"])
    result = {
        "after_one_batched_job": batched[0],
        "after_one_serial_job": serial[0],
        "cobyla_first_matches_batched_job_one": first_job(serial, batched[0]),
        "jobs_to_95_percent_own_final_running_max": {
            "batched": first_job(batched, 0.95 * batched[-1]),
            "serial": first_job(serial, 0.95 * serial[-1]),
        },
        "best_so_far_noiseless_ratio": {"batched": batched[-1], "serial": serial[-1]},
    }
    final = run.get("final", {})
    if "noiseless, BPS params" in final:
        result["returned_parameter_noiseless_ratio"] = {
            "batched": final["noiseless, BPS params"]["ratio"],
            "serial": final["noiseless, serial params"]["ratio"],
        }
    if "batched pattern search" in final:
        result["independent_device_readout_ratio"] = {
            "batched": final["batched pattern search"]["ratio"],
            "serial": final["serial baseline"]["ratio"],
        }
    return result


def audit(data_dir):
    inputs = []
    runs = {}
    ledger_rows = []
    all_logs = []
    for name in NAMES:
        path = data_dir / ("qaoa_jobs_" + name + "_ibm_fez.json")
        blob = path.read_bytes()
        run = json.loads(blob)
        runs[name] = run
        inputs.append({"filename": path.name, "sha256": hashlib.sha256(blob).hexdigest(), "bytes": len(blob)})
        ledger = run["ledger"]
        logs = ledger["log"]
        all_logs.extend(logs)
        predicted = sum(float(row["qpu_predicted"]) for row in logs)
        recorded = sum(float(row["qpu_measured"]) for row in logs)
        declared = float(ledger["qpu_seconds"])
        if len(logs) != ledger["jobs"]:
            raise ValueError(name + ": ledger job count differs from log length")
        if not math.isclose(recorded, declared, rel_tol=1e-12, abs_tol=1e-9):
            raise ValueError(name + ": QPU ledger sum differs from its log")
        ledger_rows.append({
            "run": name, "jobs": ledger["jobs"],
            "estimated_qpu_seconds": declared,
            "sum_log_qpu_predicted_seconds": predicted,
            "sum_log_qpu_measured_field_seconds": recorded,
            "all_qpu_measured_fields_equal_predicted": all(row["qpu_measured"] == row["qpu_predicted"] for row in logs),
            "measured_submission_to_result_seconds": sum(float(row["wall"]) for row in logs),
        })

    main = []
    for n in [6, 8, 10, 12]:
        run = runs[str(n) + "assets"]
        main.append({"n_assets": n, "p": run["provenance"]["p"], **quality_metrics(run)})
    replicates = []
    for dt in [0.35, 0.50, 0.60, 0.85]:
        run = runs["8assets"] if dt == 0.50 else runs["replicates_8assets"]["starts"][str(dt)]
        replicates.append({"delta_t": dt, **quality_metrics(run)})
    replica_means = {
        arm: mean(row["jobs_to_95_percent_own_final_running_max"][arm] for row in replicates)
        for arm in ["batched", "serial"]
    }
    depth = []
    for n, scan in sorted(runs["depth_scan"]["scan"].items(), key=lambda item: int(item[0])):
        values = {
            int(p): row["meas"]["noiseless"]["measured"]["ratio"]
            for p, row in scan["depths"].items()
        }
        depth.append({"n_assets": int(n), "measured_ratio_at_classically_optimized_noiseless_parameters": values,
                      "p_with_largest_measured_ratio_in_scan": max(values, key=values.get)})

    total_qpu = sum(row["estimated_qpu_seconds"] for row in ledger_rows)
    total_jobs = sum(row["jobs"] for row in ledger_rows)
    checks = {
        "jobs_equal_193": total_jobs == 193,
        "all_193_qpu_measured_fields_equal_predicted": len(all_logs) == 193 and all(row["qpu_measured"] == row["qpu_predicted"] for row in all_logs),
        "table4_cobyla_match_jobs_equal_3_4_5_12": [row["cobyla_first_matches_batched_job_one"] for row in main] == [3, 4, 5, 12],
        "table4_batched_jobs_to_95_equal_2_2_1_1": [row["jobs_to_95_percent_own_final_running_max"]["batched"] for row in main] == [2, 2, 1, 1],
        "table4_serial_jobs_to_95_equal_6_8_5_5": [row["jobs_to_95_percent_own_final_running_max"]["serial"] for row in main] == [6, 8, 5, 5],
        "table7_mean_jobs_equal_1_5_and_5_75": replica_means == {"batched": 1.5, "serial": 5.75},
        "all_depth_scan_maxima_at_p_2_or_3": all(row["p_with_largest_measured_ratio_in_scan"] in [2, 3] for row in depth),
        "readme_1617_seconds_disagrees_with_released_ledger_sum": not math.isclose(total_qpu, 1617.0, abs_tol=1.0),
    }
    return {
        "schema_version": 1,
        "upstream_commit": COMMIT, "upstream_url": UPSTREAM,
        "scope": "Offline arithmetic and released-trace audit only; no notebook execution, independent circuit simulation, or new device measurements.",
        "inputs": inputs,
        "ledger_by_run": ledger_rows,
        "totals": {"jobs": total_jobs, "estimated_qpu_seconds": total_qpu,
                   "estimated_qpu_minutes": total_qpu / 60,
                   "measured_submission_to_result_seconds": sum(row["measured_submission_to_result_seconds"] for row in ledger_rows)},
        "important_interpretation": {
            "qpu_time": "The qpu_measured fields are not independent measurements. Paper Sec. IV and Appendix B disclose a metrics-key fallback bug; these values are estimates.",
            "readme_time_discrepancy": "README states 1617 seconds; the six released ledgers sum to approximately 2016.86 seconds (33.61 minutes), consistent with the paper acknowledgement of about 34 estimated minutes.",
            "95_percent": "Each arm reaches 95% of its own final running maximum of the released noiseless conditional approximation ratio; this is an oracle diagnostic, not 95% device quality or an optimum success probability.",
            "comparison": "Same nominal job and shot budgets compare two classical optimizer packages on QAOA. This is not quantum speedup over a classical solver.",
        },
        "table4_main_runs": main, "table7_initializations": replicates,
        "table7_mean_jobs_to_95_percent_own_final": replica_means,
        "table6_depth_scan": depth,
        "checks": checks, "all_checks_passed": all(checks.values()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True, help="Local directory containing the six released JSON files")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("qaoa_audit_results.json"))
    args = parser.parse_args()
    result = audit(args.data_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "totals": result["totals"], "checks": result["checks"], "all_checks_passed": result["all_checks_passed"]}, ensure_ascii=False, indent=2))
    if not result["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
