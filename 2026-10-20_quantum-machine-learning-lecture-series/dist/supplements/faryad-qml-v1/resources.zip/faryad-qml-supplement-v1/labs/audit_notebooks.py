"""Independent checks for selected statements; does not execute author notebooks or QPU jobs."""
from pathlib import Path
import json
import argparse
import hashlib
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=ROOT/'raw/quantum-algorithms-first-principles-22954602b59d586c0727cf6110292b7000659db2')
parser.add_argument('--output', type=Path, default=ROOT/'working/notebook_audit_results.json')
args=parser.parse_args()
SRC=args.source_dir
if not (SRC/'notebooks').is_dir(): raise SystemExit('Expected --source-dir with a notebooks/ directory')

def exp_h(H,t):
    w,v=np.linalg.eigh(H)
    return (v*np.exp(-1j*t*w))@v.conj().T

# Enumerate measurement branches for 3-bit iterative phase estimation.
# Retained mode updates eigenstate posterior; fresh mode resets it each round.
phases=np.array([1/8,6/8]); weights=np.array([.3,.7]); bits=3

def ipe(fresh):
    branches=[([],1.,weights)]
    for step in range(bits):
        nxt=[]
        for low,branch_prob,posterior in branches:
            w=weights if fresh else posterior
            correction=sum(b/2**(step-r+1) for r,b in enumerate(low))
            phase=2**(bits-1-step)*phases-correction
            p0=np.cos(np.pi*phase)**2
            for b in [0,1]:
                likelihood=p0 if b==0 else 1-p0
                prob=float(w@likelihood)
                if prob>1e-15:
                    nxt.append((low+[b],branch_prob*prob,w*likelihood/prob))
        branches=nxt
    result=np.zeros(2**bits)
    for low,p,_ in branches: result[sum(b*2**r for r,b in enumerate(low))]+=p
    return result
kept=ipe(False); fresh=ipe(True)
assert np.allclose(kept,[0,.3,0,0,0,0,.7,0])
assert np.all(fresh>0)

# Two noncommuting Hermitian terms: local error and fixed-time global error.
X=np.array([[0,1],[1,0]],complex); Z=np.diag([1.,-1.]); H=X+.7*Z
K=np.array([32,64,128,256,512]); dt=1/K
local=[];global1=[];global2=[]
for k,h in zip(K,dt):
    first=exp_h(X,h)@exp_h(.7*Z,h)
    sym=exp_h(X,h/2)@exp_h(.7*Z,h)@exp_h(X,h/2)
    local.append(np.linalg.norm(first-exp_h(H,h),2))
    global1.append(np.linalg.norm(np.linalg.matrix_power(first,int(k))-exp_h(H,1),2))
    global2.append(np.linalg.norm(np.linalg.matrix_power(sym,int(k))-exp_h(H,1),2))
slopes={n:float(np.polyfit(np.log(dt),np.log(a),1)[0]) for n,a in [('local_first',local),('global_first',global1),('global_symmetric',global2)]}
assert abs(slopes['local_first']-2)<.01
assert abs(slopes['global_first']-1)<.01
assert abs(slopes['global_symmetric']-2)<.01

# Reuse only rounded published coefficients, not the chemistry code/integrals.
I=np.eye(2); Y=np.array([[0,-1j],[1j,0]])
base=-1.052373*np.eye(4)+.397937*np.kron(Z,I)-.397937*np.kron(I,Z)-.011280*np.kron(Z,Z)
H5=base+.180931*np.kron(X,X)
H6=base+(.180931/2)*(np.kron(X,X)+np.kron(Y,Y))
phys=np.ix_([1,2],[1,2]) # odd-parity physical sector |01>, |10>
assert np.allclose(H5[phys],H6[phys])
assert not np.allclose(H5,H6)
energies=[float(np.linalg.eigvalsh(h)[0]+.719969) for h in [H5,H6]]
assert np.allclose(energies,[-1.137306,-1.137306],atol=2e-6)

# HHL state and postselection probability for the teaching 2x2 problem.
A=np.array([[1.5,.5],[.5,1.5]]);b=np.array([1.,0.]);sol=np.linalg.solve(A,b);normed=sol/np.linalg.norm(sol)
success=float(np.linalg.norm(sol)**2)
assert np.allclose(normed,[3/np.sqrt(10),-1/np.sqrt(10)])
assert np.isclose(success,.625)

inventory=[]
for f in sorted((SRC/'notebooks').glob('*.ipynb')):
    n=json.loads(f.read_text());cells=[c for c in n['cells'] if c['cell_type']=='code']
    inventory.append({'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'code_cells':len(cells),'stored_execution_count_cells':sum(c.get('execution_count') is not None for c in cells),'stored_output_cells':sum(bool(c.get('outputs')) for c in cells),'stored_error_outputs':sum(o.get('output_type')=='error' for c in cells for o in c.get('outputs',[]))})
assert len(inventory)==14
out={'scope':'Independent NumPy checks and static notebook inspection; no author notebook execution, no QPU submission','numpy':np.__version__,'notebooks':inventory,'ipe':{'kept_register':kept.tolist(),'fresh_register_each_round':fresh.tolist()},'trotter':{'model':'H=X+0.7Z, total time 1, K=32..512','fitted_slopes':slopes},'h2':{'input':'rounded saved notebook coefficients, nuclear repulsion 0.719969 Hartree','five_term_ground_energy':energies[0],'six_term_ground_energy':energies[1],'equal_on_physical_odd_parity_sector':True,'equal_on_full_4d_space':False},'hhl':{'normalized_solution':normed.tolist(),'postselection_probability':success}}
p=args.output;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
